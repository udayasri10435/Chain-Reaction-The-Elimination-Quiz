import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Gemini API initialization on server-side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', hasKey: Boolean(process.env.GEMINI_API_KEY) });
});

// Generate dynamic chain reaction quiz using Gemini 3.8 Flash
app.post('/api/generate-chain', async (req, res) => {
  try {
    const { topic, mode = 'trivia', linkCount = 7 } = req.body;
    const safeTopic = (typeof topic === 'string' && topic.trim()) ? topic.trim() : 'General Knowledge & Pop Culture';

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
      });
    }

    const systemPrompt = `You are the master game designer for the high-stakes game show 'Chain Reaction: The Elimination Quiz'.
Rules of Chain Reaction:
1. Every answer MUST logically or factually connect directly to the previous answer.
2. In 'trivia' mode:
   - Question 1 asks a question whose answer is Answer 1.
   - Question 2 MUST explicitly incorporate Answer 1 in its clue or context, and lead to Answer 2.
   - Question 3 MUST explicitly incorporate Answer 2 in its clue, and lead to Answer 3.
   - And so on for all ${linkCount} links!
   - Each question must have exactly 4 choices (1 correct answer + 3 clever, plausible distractors).
   - Also provide a concise 'connectionExplanation' explaining how Answer N connects to Question N+1.
3. In 'word' mode:
   - Provide a sequence of words where each adjacent pair forms a well-known compound word, phrase, idiom, or pop culture pair (e.g., SILVER -> LINING -> CLOUD -> NINE -> LIVES -> SAVER -> MONEY).
   - For each link (except the revealed starter word), provide 4 word choices (1 correct next word + 3 tricky plausible alternatives that sound like compounds or associations).
   - Provide a connection explanation for each link.`;

    const userPrompt = `Generate an intense, verified ${linkCount}-link chain reaction quiz for topic: "${safeTopic}".
Mode: ${mode}.
Make the questions progressively more engaging and suspenseful. Distractors must be tricky and realistic.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Catchy title for this specific chain reaction ladder' },
            topic: { type: Type.STRING, description: 'The topic or theme' },
            difficulty: { type: Type.STRING, description: 'Normal, Hard, or Extreme' },
            starterLink: { type: Type.STRING, description: 'The starting anchor answer/word that kicks off the chain' },
            starterDescription: { type: Type.STRING, description: 'Brief context or introduction to the chain' },
            links: {
              type: Type.ARRAY,
              description: 'The chain links following the starter link',
              items: {
                type: Type.OBJECT,
                properties: {
                  linkIndex: { type: Type.INTEGER, description: '1-based index of this link' },
                  question: { type: Type.STRING, description: 'The prompt or question connecting to previous answer' },
                  correctAnswer: { type: Type.STRING, description: 'The correct answer connecting this link' },
                  distractors: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: '3 tricky incorrect answer choices',
                  },
                  connectionExplanation: { type: Type.STRING, description: 'Why this connects to the previous link' },
                  hint: { type: Type.STRING, description: 'A subtle clue if requested' },
                },
                required: ['linkIndex', 'question', 'correctAnswer', 'distractors', 'connectionExplanation'],
              },
            },
          },
          required: ['title', 'topic', 'difficulty', 'starterLink', 'links'],
        },
      },
    });

    const outputText = response.text?.trim();
    if (!outputText) {
      throw new Error('Empty response from model');
    }

    const parsedData = JSON.parse(outputText);
    return res.json(parsedData);
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Unknown generation error';
    console.error('Gemini chain generation failed:', errorMsg);
    return res.status(500).json({ error: errorMsg });
  }
});

// Serve frontend in development or production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Chain Reaction server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();

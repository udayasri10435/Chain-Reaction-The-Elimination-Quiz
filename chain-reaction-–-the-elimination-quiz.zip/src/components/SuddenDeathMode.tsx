import React, { useState, useEffect, useRef } from 'react';
import { Skull, Flame, Zap, Shield, ArrowRight, RefreshCw, Trophy } from 'lucide-react';
import { SUDDEN_DEATH_POOL } from '../data/chains';
import { sound } from '../utils/audio';

interface SuddenDeathModeProps {
  onBackToMenu: () => void;
  soundEnabled: boolean;
  hasShield: boolean;
}

export const SuddenDeathMode: React.FC<SuddenDeathModeProps> = ({
  onBackToMenu,
  soundEnabled,
  hasShield: initialShield,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [bestStreak, setBestStreak] = useState<number>(() => {
    return Number(localStorage.getItem('chain_reaction_best_gauntlet') || '0');
  });
  const [shieldAvailable, setShieldAvailable] = useState<boolean>(initialShield);
  const [isEliminated, setIsEliminated] = useState<boolean>(false);
  const [failedQuestion, setFailedQuestion] = useState<{
    prompt: string;
    chosen: string;
    correct: string;
    explanation: string;
  } | null>(null);

  const [timeRemaining, setTimeRemaining] = useState<number>(12);
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);

  const currentLink = SUDDEN_DEATH_POOL[currentIndex % SUDDEN_DEATH_POOL.length];
  const previousAnswer =
    currentIndex === 0
      ? 'Oxygen'
      : SUDDEN_DEATH_POOL[(currentIndex - 1) % SUDDEN_DEATH_POOL.length].correctAnswer;

  // Multiplier tiers based on streak
  const multiplier =
    streak >= 15 ? 10 : streak >= 10 ? 5 : streak >= 6 ? 3 : streak >= 3 ? 2 : 1;

  // Timer countdown
  useEffect(() => {
    if (isEliminated) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentIndex, isEliminated, shieldAvailable]);

  // Audio tick
  useEffect(() => {
    if (!isEliminated && timeRemaining <= 5 && timeRemaining > 0) {
      sound.playTick(true);
    }
  }, [timeRemaining, isEliminated]);

  const handleTimeOut = () => {
    if (shieldAvailable) {
      sound.playShieldDeflect();
      setShieldAvailable(false);
      setTimeRemaining(10);
      return;
    }

    sound.playChainSnap();
    setIsEliminated(true);
    setFailedQuestion({
      prompt: currentLink.question,
      chosen: 'TIME EXPIRED',
      correct: currentLink.correctAnswer,
      explanation: currentLink.connectionExplanation,
    });
  };

  const handleChoice = (choice: string) => {
    if (isEliminated || selectedChoice) return;
    setSelectedChoice(choice);

    if (choice === currentLink.correctAnswer) {
      sound.playLinkForge();
      const points = 100 * multiplier + timeRemaining * 10;
      setScore((s) => s + points);
      const newStreak = streak + 1;
      setStreak(newStreak);

      if (newStreak > bestStreak) {
        setBestStreak(newStreak);
        localStorage.setItem('chain_reaction_best_gauntlet', String(newStreak));
      }

      // Next link after brief pause
      setTimeout(() => {
        setSelectedChoice(null);
        setTimeRemaining(12);
        setCurrentIndex((i) => i + 1);
      }, 400);
    } else {
      // Wrong choice
      if (shieldAvailable) {
        sound.playShieldDeflect();
        setShieldAvailable(false);
        setSelectedChoice(null);
        return;
      }

      sound.playChainSnap();
      setIsEliminated(true);
      setFailedQuestion({
        prompt: currentLink.question,
        chosen: choice,
        correct: currentLink.correctAnswer,
        explanation: currentLink.connectionExplanation,
      });
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setScore(0);
    setStreak(0);
    setIsEliminated(false);
    setFailedQuestion(null);
    setShieldAvailable(initialShield);
    setSelectedChoice(null);
    setTimeRemaining(12);
  };

  const choices = [currentLink.correctAnswer, ...currentLink.distractors].sort(
    (a, b) => (a.charCodeAt(0) % 5) - (b.charCodeAt(0) % 5)
  );

  return (
    <div className="w-full max-w-3xl mx-auto py-4 px-2 sm:px-4">
      {/* Top Gauntlet Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 p-4 bg-neutral-900 border border-red-500/30 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-red-500/10 rounded-lg border border-red-500/30 text-red-500">
            <Skull className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-red-400">
                Sudden Death Gauntlet
              </span>
              <span className="text-[11px] text-neutral-500">· 1 Mistake = Out</span>
            </div>
            <h2 className="font-display text-xl font-bold text-white">
              Endless Chain Reaction
            </h2>
          </div>
        </div>

        {/* Meters */}
        <div className="flex items-center gap-4 text-right">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">
              Multiplier
            </span>
            <span className="font-mono text-base font-extrabold text-amber-400 tabular-nums flex items-center gap-1 justify-end">
              <Flame className="w-4 h-4 text-amber-500" />
              {multiplier}x
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">
              Chain Score
            </span>
            <span className="font-mono text-base font-extrabold text-white tabular-nums">
              {score}
            </span>
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-500 block">
              Streak
            </span>
            <span className="font-mono text-base font-extrabold text-emerald-400 tabular-nums">
              {streak}
            </span>
          </div>
        </div>
      </div>

      {!isEliminated ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl relative">
          {/* Previous Link Anchor */}
          <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2 text-xs sm:text-sm">
              <span className="text-neutral-500">Connecting From:</span>
              <span className="flex items-center gap-1 font-bold text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/20">
                {previousAnswer}
                <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
              </span>
            </div>

            <div className="flex items-center gap-3">
              {shieldAvailable && (
                <span className="text-xs text-amber-400 flex items-center gap-1 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                  <Shield className="w-3.5 h-3.5" /> Shield
                </span>
              )}
              <div className="font-mono font-bold text-sm text-red-400 tabular-nums">
                {timeRemaining}s
              </div>
            </div>
          </div>

          {/* Time Bar */}
          <div className="w-full h-1.5 bg-neutral-800 rounded-full mb-6 overflow-hidden">
            <div
              className={`h-full transition-all duration-1000 ease-linear rounded-full ${
                timeRemaining <= 4 ? 'bg-red-500 animate-pulse' : 'bg-amber-500'
              }`}
              style={{ width: `${(timeRemaining / 12) * 100}%` }}
            />
          </div>

          {/* Prompt */}
          <div className="mb-6">
            <span className="text-xs font-semibold uppercase text-amber-400 block mb-1">
              Link #{currentIndex + 1}
            </span>
            <h3 className="text-lg sm:text-xl font-semibold text-white leading-relaxed">
              {currentLink.question}
            </h3>
          </div>

          {/* Choices */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {choices.map((choice) => {
              const isSelected = selectedChoice === choice;
              return (
                <button
                  key={choice}
                  disabled={Boolean(selectedChoice)}
                  onClick={() => handleChoice(choice)}
                  className={`p-4 rounded-xl border text-left font-medium text-sm sm:text-base transition-all ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                      : 'bg-neutral-950/70 border-neutral-800 text-neutral-200 hover:border-amber-500/50 hover:bg-neutral-800'
                  }`}
                >
                  {choice}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        /* Elimination Autopsy */
        <div className="bg-neutral-900 border-2 border-red-500 rounded-2xl p-6 sm:p-8 shadow-2xl animate-scaleUp">
          <div className="flex items-center gap-3 mb-5">
            <div className="p-3 bg-red-500/20 text-red-500 rounded-xl">
              <Skull className="w-7 h-7" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase text-red-400">
                Fatal Mistake
              </span>
              <h3 className="font-display text-2xl font-bold text-white">
                GAUNTLET ELIMINATION
              </h3>
            </div>
          </div>

          {failedQuestion && (
            <div className="p-4 bg-neutral-950/80 rounded-xl border border-neutral-800 space-y-3 mb-6">
              <p className="text-sm text-neutral-300">"{failedQuestion.prompt}"</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-2.5 bg-red-950/40 border border-red-900/40 rounded">
                  <span className="font-bold text-red-400 block mb-0.5">Your Choice (Broke Chain):</span>
                  <span className="line-through text-red-200">{failedQuestion.chosen}</span>
                </div>
                <div className="p-2.5 bg-emerald-950/40 border border-emerald-900/40 rounded">
                  <span className="font-bold text-emerald-400 block mb-0.5">Connecting Answer:</span>
                  <span className="text-emerald-200 font-semibold">{failedQuestion.correct}</span>
                </div>
              </div>
              <p className="text-xs text-neutral-400 border-t border-neutral-800/80 pt-2">
                <strong className="text-amber-400">Connection:</strong> {failedQuestion.explanation}
              </p>
            </div>
          )}

          {/* Final stats */}
          <div className="grid grid-cols-3 gap-3 mb-6 text-center">
            <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
              <span className="text-[10px] text-neutral-500 uppercase block">Links Forged</span>
              <span className="font-mono text-xl font-bold text-white">{currentIndex}</span>
            </div>
            <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
              <span className="text-[10px] text-neutral-500 uppercase block">Total Score</span>
              <span className="font-mono text-xl font-bold text-amber-400">{score}</span>
            </div>
            <div className="p-3 bg-neutral-950 rounded-lg border border-neutral-800">
              <span className="text-[10px] text-neutral-500 uppercase block">Best Record</span>
              <span className="font-mono text-xl font-bold text-emerald-400">{bestStreak}</span>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleRestart}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-amber-400 hover:bg-amber-300 font-bold text-neutral-950 rounded-xl shadow-lg transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              Try Gauntlet Again
            </button>
            <button
              onClick={onBackToMenu}
              className="py-3 px-5 bg-neutral-800 hover:bg-neutral-700 font-semibold text-white rounded-xl border border-neutral-700 transition-all"
            >
              Solo Mode
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

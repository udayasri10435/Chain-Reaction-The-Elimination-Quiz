import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Timer, HelpCircle, ArrowRight, ShieldCheck } from 'lucide-react';
import { ChainLink } from '../types/game';
import { sound } from '../utils/audio';

interface QuestionCardProps {
  link: ChainLink;
  previousAnswer: string;
  totalLinks: number;
  timeRemaining: number;
  totalTime: number;
  hasShield: boolean;
  onSelectAnswer: (answer: string) => void;
  disabled: boolean;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  link,
  previousAnswer,
  totalLinks,
  timeRemaining,
  totalTime,
  hasShield,
  onSelectAnswer,
  disabled,
}) => {
  const [showHint, setShowHint] = useState<boolean>(false);
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);
  const prevTimeRef = useRef(timeRemaining);

  // Shuffle choices deterministically per link so they don't jump around on re-renders
  const choices = useMemo(() => {
    const list = [link.correctAnswer, ...link.distractors];
    // Simple deterministic shuffle based on linkIndex
    for (let i = list.length - 1; i > 0; i--) {
      const j = (i * 7 + link.linkIndex * 13) % (i + 1);
      [list[i], list[j]] = [list[j], list[i]];
    }
    return list;
  }, [link]);

  // Audio tick synchronization on time countdown
  useEffect(() => {
    if (timeRemaining !== prevTimeRef.current && timeRemaining <= 10 && timeRemaining > 0 && !disabled) {
      sound.playTick(timeRemaining <= 4);
    }
    prevTimeRef.current = timeRemaining;
  }, [timeRemaining, disabled]);

  const handleChoice = (choice: string) => {
    if (disabled || selectedChoice) return;
    setSelectedChoice(choice);
    onSelectAnswer(choice);
  };

  // Reset local state when link changes
  useEffect(() => {
    setShowHint(false);
    setSelectedChoice(null);
  }, [link.linkIndex]);

  const timePercent = Math.max(0, (timeRemaining / totalTime) * 100);
  const isUrgent = timeRemaining <= 5;

  return (
    <div className="w-full bg-neutral-900 border border-neutral-800 rounded-xl p-5 sm:p-7 shadow-2xl relative overflow-hidden">
      {/* Top Meta Header: Prior Link Connection */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5 pb-4 border-b border-neutral-800">
        <div className="flex items-center gap-2 text-xs sm:text-sm">
          <span className="text-neutral-500 font-medium">Bridged From:</span>
          <span className="flex items-center gap-1.5 font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/20">
            {previousAnswer}
            <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
          </span>
        </div>

        <div className="flex items-center gap-4">
          {hasShield && (
            <div className="flex items-center gap-1 text-xs text-amber-400/90 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Shield Active</span>
            </div>
          )}

          <div className="flex items-center gap-2 text-xs sm:text-sm">
            <Timer className={`w-4 h-4 ${isUrgent ? 'text-red-500 animate-pulse' : 'text-neutral-400'}`} />
            <span
              className={`font-mono tabular-nums font-bold text-base ${
                isUrgent ? 'text-red-400' : 'text-neutral-200'
              }`}
            >
              {timeRemaining}s
            </span>
          </div>
        </div>
      </div>

      {/* Timer Bar */}
      <div className="w-full h-1.5 bg-neutral-800 rounded-full mb-6 overflow-hidden">
        <div
          className={`h-full transition-all duration-1000 ease-linear rounded-full ${
            isUrgent
              ? 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.8)]'
              : timePercent < 50
              ? 'bg-amber-500'
              : 'bg-emerald-500'
          }`}
          style={{ width: `${timePercent}%` }}
        />
      </div>

      {/* The Question Prompt */}
      <div className="mb-7">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold tracking-wider uppercase text-amber-400">
            Link {link.linkIndex} of {totalLinks}
          </span>
          {link.hint && (
            <button
              onClick={() => setShowHint(!showHint)}
              className="text-xs text-neutral-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              {showHint ? 'Hide Hint' : 'Subtle Hint'}
            </button>
          )}
        </div>

        <h2 className="text-lg sm:text-xl font-semibold text-white leading-relaxed text-balance">
          {link.question}
        </h2>

        {showHint && link.hint && (
          <div className="mt-3 p-3 bg-neutral-950/80 border border-neutral-800 rounded-lg text-xs text-amber-300/90 animate-fadeIn">
            <span className="font-semibold text-amber-400">Hint:</span> {link.hint}
          </div>
        )}
      </div>

      {/* Answer Options Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
        {choices.map((choice, index) => {
          const letter = String.fromCharCode(65 + index); // A, B, C, D
          const isSelected = selectedChoice === choice;

          return (
            <button
              key={choice}
              disabled={disabled}
              onClick={() => handleChoice(choice)}
              className={`group flex items-center justify-between p-4 rounded-xl border text-left transition-all duration-150 ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-400 text-white shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                  : 'bg-neutral-950/60 border-neutral-800 text-neutral-200 hover:border-amber-500/50 hover:bg-neutral-800/80 hover:text-white'
              } disabled:cursor-not-allowed`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`flex items-center justify-center w-7 h-7 rounded-lg font-mono text-xs font-bold transition-colors ${
                    isSelected
                      ? 'bg-amber-400 text-neutral-950'
                      : 'bg-neutral-800 text-neutral-400 group-hover:bg-neutral-700 group-hover:text-white'
                  }`}
                >
                  {letter}
                </span>
                <span className="font-medium text-sm sm:text-base leading-tight">
                  {choice}
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* High-stakes Warning Footer */}
      <div className="mt-6 pt-4 border-t border-neutral-800/60 flex items-center justify-between text-xs text-neutral-500">
        <span>One wrong choice breaks the entire chain.</span>
        <span className="font-mono text-[11px] text-neutral-500">
          Keys: 1-4 or click
        </span>
      </div>
    </div>
  );
};

import React from 'react';
import { Play, Sparkles, Flame, ShieldAlert, BookOpen, Layers } from 'lucide-react';
import { ChainDeck } from '../types/game';

interface DeckSelectorProps {
  decks: ChainDeck[];
  selectedDeckId: string;
  onSelectDeck: (deck: ChainDeck) => void;
  onOpenAIGenerator: () => void;
  onStartSuddenDeath: () => void;
}

export const DeckSelector: React.FC<DeckSelectorProps> = ({
  decks,
  selectedDeckId,
  onSelectDeck,
  onOpenAIGenerator,
  onStartSuddenDeath,
}) => {
  return (
    <div className="w-full">
      {/* Title & Banner */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
            <Layers className="w-3.5 h-3.5" /> High-Stakes Ladders
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
            Choose Your Chain Reaction
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            Every answer connects to the previous one. One wrong link = elimination.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onStartSuddenDeath}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-red-400 bg-red-950/40 hover:bg-red-900/50 border border-red-800/60 rounded-xl transition-all"
          >
            <Flame className="w-3.5 h-3.5" />
            Endless Gauntlet
          </button>
          <button
            onClick={onOpenAIGenerator}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-purple-300 bg-purple-950/40 hover:bg-purple-900/50 border border-purple-800/60 rounded-xl transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Custom AI Chain
          </button>
        </div>
      </div>

      {/* Grid of Decks */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {decks.map((deck) => {
          const isSelected = deck.id === selectedDeckId;
          const isWord = deck.mode === 'word';

          return (
            <div
              key={deck.id}
              onClick={() => onSelectDeck(deck)}
              className={`group flex flex-col justify-between p-5 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-neutral-900 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.2)] ring-1 ring-amber-400/50'
                  : 'bg-neutral-900/60 hover:bg-neutral-900 border-neutral-800 hover:border-neutral-700'
              }`}
            >
              <div>
                {/* Clean unboxed metadata with separators (zero-pill discipline) */}
                <div className="flex items-center gap-2 text-xs text-neutral-400 mb-2">
                  <span className="font-semibold text-neutral-300">{deck.topic}</span>
                  <span aria-hidden="true">·</span>
                  <span>{deck.difficulty}</span>
                  <span aria-hidden="true">·</span>
                  <span>{deck.links.length} Links</span>
                </div>

                <h3 className="font-display font-bold text-lg text-white group-hover:text-amber-300 transition-colors mb-2">
                  {deck.title}
                </h3>

                <p className="text-xs text-neutral-400 line-clamp-2 mb-4 leading-relaxed">
                  {deck.starterDescription}
                </p>
              </div>

              {/* Starter Link Anchor Preview */}
              <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between">
                <div className="text-xs">
                  <span className="text-neutral-500 block text-[10px] uppercase font-bold">
                    Anchor:
                  </span>
                  <span className="font-semibold text-amber-400">
                    "{deck.starterLink}"
                  </span>
                </div>

                <button
                  type="button"
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    isSelected
                      ? 'bg-amber-400 text-neutral-950 shadow-md'
                      : 'bg-neutral-800 text-neutral-200 group-hover:bg-amber-400 group-hover:text-neutral-950'
                  }`}
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Play</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

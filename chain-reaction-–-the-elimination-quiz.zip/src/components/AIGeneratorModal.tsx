import React, { useState } from 'react';
import { Sparkles, Loader2, Play, Flame, AlertCircle } from 'lucide-react';
import { ChainDeck } from '../types/game';

interface AIGeneratorModalProps {
  onStartCustomDeck: (deck: ChainDeck) => void;
  onClose: () => void;
}

const SUGGESTIONS = [
  'Space Exploration & Rockets',
  'Classic Rock to Heavy Metal',
  'Ancient Rome to Modern Tech',
  'Culinary Arts & Chemistry',
  'Hollywood Blockbusters',
  'World Geography & Great Rivers',
];

export const AIGeneratorModal: React.FC<AIGeneratorModalProps> = ({
  onStartCustomDeck,
  onClose,
}) => {
  const [topic, setTopic] = useState<string>('');
  const [mode, setMode] = useState<'trivia' | 'word'>('trivia');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-chain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          mode,
          linkCount: 6,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const generatedData = await response.json();
      const newDeck: ChainDeck = {
        id: `ai-${Date.now()}`,
        title: generatedData.title || `Chain Reaction: ${topic}`,
        topic: generatedData.topic || topic,
        mode: mode,
        difficulty: generatedData.difficulty || 'Standard',
        starterLink: generatedData.starterLink || 'Start',
        starterDescription: generatedData.starterDescription || 'AI Generated Chain Reaction',
        links: generatedData.links || [],
      };

      onStartCustomDeck(newDeck);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to generate custom chain';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-neutral-900 border border-purple-500/40 rounded-2xl p-6 sm:p-7 shadow-[0_0_40px_rgba(168,85,247,0.2)] relative">
        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-xl border border-purple-500/30">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-400">
              AI Chain Studio
            </span>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-white">
              Forge A Bespoke Chain
            </h2>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-neutral-400 mb-5 leading-relaxed">
          Type any theme, era, or obsession. Gemini will construct a linked chain reaction ladder where every answer logically bridges to the next!
        </p>

        {/* Mode Selector */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-neutral-400 block mb-2">
            Chain Style:
          </label>
          <div className="grid grid-cols-2 gap-2 p-1 bg-neutral-950 rounded-xl border border-neutral-800">
            <button
              type="button"
              onClick={() => setMode('trivia')}
              className={`py-2 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'trivia'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Trivia Bridges
            </button>
            <button
              type="button"
              onClick={() => setMode('word')}
              className={`py-2 text-xs font-semibold rounded-lg transition-colors ${
                mode === 'word'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Word Compounds
            </button>
          </div>
        </div>

        {/* Input Field */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-neutral-400 block mb-2">
            Topic or Universe:
          </label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !loading && handleGenerate()}
            placeholder="e.g. 90s Grunge, Norse Mythology, Cyberpunk..."
            className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 focus:border-purple-400 rounded-xl text-white text-sm placeholder-neutral-600 focus:outline-none focus:ring-1 focus:ring-purple-400 transition-all"
          />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="mb-6">
          <span className="text-[11px] text-neutral-500 block mb-2 font-medium">
            Try a popular topic:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {SUGGESTIONS.map((sug) => (
              <button
                key={sug}
                type="button"
                onClick={() => setTopic(sug)}
                className="text-xs px-2.5 py-1 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 hover:border-purple-500/40 text-neutral-300 hover:text-purple-300 rounded-lg transition-all"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-4 p-3 bg-red-950/50 border border-red-800/60 rounded-xl text-xs text-red-300 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <button
            type="button"
            disabled={loading || !topic.trim()}
            onClick={handleGenerate}
            className="flex-1 flex items-center justify-center gap-2 py-3 px-5 bg-purple-600 hover:bg-purple-500 active:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed font-bold text-white text-sm rounded-xl shadow-lg transition-all"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Forging Chain...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                Generate & Play
              </>
            )}
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={onClose}
            className="py-3 px-5 bg-neutral-800 hover:bg-neutral-700 font-semibold text-neutral-300 text-sm rounded-xl border border-neutral-700 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Trophy, Award, Flame, Skull, CheckCircle, RefreshCcw } from 'lucide-react';
import { PlayerStats } from '../types/game';

interface LeaderboardViewProps {
  stats: PlayerStats;
  onClearStats: () => void;
  onClose: () => void;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  stats,
  onClearStats,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-6 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/30">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Career Track Record
              </span>
              <h2 className="font-display text-2xl font-bold text-white">
                Chain Mastery Stats
              </h2>
            </div>
          </div>
        </div>

        {/* Big 4 Stats */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="p-4 bg-neutral-950/70 rounded-xl border border-neutral-800">
            <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Unbroken Chains</span>
            </div>
            <span className="font-mono text-2xl font-extrabold text-white tabular-nums">
              {stats.unbrokenChainsCompleted}
            </span>
          </div>

          <div className="p-4 bg-neutral-950/70 rounded-xl border border-neutral-800">
            <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Gauntlet Best Streak</span>
            </div>
            <span className="font-mono text-2xl font-extrabold text-amber-400 tabular-nums">
              {stats.longestSurvivalStreak}
            </span>
          </div>

          <div className="p-4 bg-neutral-950/70 rounded-xl border border-neutral-800">
            <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
              <Award className="w-3.5 h-3.5 text-cyan-400" />
              <span>Links Connected</span>
            </div>
            <span className="font-mono text-2xl font-extrabold text-cyan-300 tabular-nums">
              {stats.totalLinksForged}
            </span>
          </div>

          <div className="p-4 bg-neutral-950/70 rounded-xl border border-neutral-800">
            <div className="flex items-center gap-1.5 text-xs text-neutral-400 mb-1">
              <Skull className="w-3.5 h-3.5 text-red-400" />
              <span>Chain Severed Deaths</span>
            </div>
            <span className="font-mono text-2xl font-extrabold text-red-400 tabular-nums">
              {stats.eliminations}
            </span>
          </div>
        </div>

        {/* Milestone Badges */}
        <div className="mb-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-3">
            Chain Badges
          </h4>
          <div className="space-y-2 text-xs">
            <div
              className={`p-3 rounded-xl border flex items-center justify-between ${
                stats.unbrokenChainsCompleted >= 1
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                  : 'bg-neutral-950/40 border-neutral-800 text-neutral-500'
              }`}
            >
              <div>
                <span className="font-bold block">First Titanium Chain</span>
                <span className="text-[11px] opacity-80">Forge 1 full unbroken chain</span>
              </div>
              <span className="font-bold">{stats.unbrokenChainsCompleted >= 1 ? 'Unlocked' : 'Locked'}</span>
            </div>

            <div
              className={`p-3 rounded-xl border flex items-center justify-between ${
                stats.longestSurvivalStreak >= 10
                  ? 'bg-red-500/10 border-red-500/30 text-red-200'
                  : 'bg-neutral-950/40 border-neutral-800 text-neutral-500'
              }`}
            >
              <div>
                <span className="font-bold block">Gauntlet Iron Heart</span>
                <span className="text-[11px] opacity-80">Survive 10 links in Sudden Death</span>
              </div>
              <span className="font-bold">{stats.longestSurvivalStreak >= 10 ? 'Unlocked' : 'Locked'}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
          <button
            onClick={onClearStats}
            className="flex items-center gap-1.5 text-xs text-neutral-500 hover:text-red-400 transition-colors"
          >
            <RefreshCcw className="w-3.5 h-3.5" />
            Reset Record
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-neutral-800 hover:bg-neutral-700 font-semibold text-white text-xs rounded-xl border border-neutral-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

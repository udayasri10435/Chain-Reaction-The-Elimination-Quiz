import React from 'react';
import { Volume2, VolumeX, Shield, ShieldAlert, Sparkles, RefreshCw } from 'lucide-react';
import { GameMode } from '../types/game';

interface HeaderProps {
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  hasShield: boolean;
  onToggleShield: () => void;
  onResetGame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  soundEnabled,
  onToggleSound,
  hasShield,
  onToggleShield,
  onResetGame,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-neutral-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={onResetGame}
          className="group flex items-center gap-2 text-left focus:outline-none"
        >
          <span className="font-display text-xl sm:text-2xl font-extrabold tracking-tight text-white group-hover:text-amber-400 transition-colors">
            CHAIN<span className="text-amber-400">REACTION</span>
          </span>
        </button>

        {/* Zone 2: 4-5 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8 text-sm font-medium">
          <button
            onClick={() => onSelectMode('trivia')}
            className={`whitespace-nowrap transition-colors ${
              currentMode === 'trivia'
                ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-amber-400 decoration-2'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Solo Ladders
          </button>
          <button
            onClick={() => onSelectMode('word')}
            className={`whitespace-nowrap transition-colors ${
              currentMode === 'word'
                ? 'text-amber-400 font-semibold underline underline-offset-8 decoration-amber-400 decoration-2'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Word Forge
          </button>
          <button
            onClick={() => onSelectMode('sudden_death')}
            className={`whitespace-nowrap transition-colors ${
              currentMode === 'sudden_death'
                ? 'text-red-400 font-semibold underline underline-offset-8 decoration-red-400 decoration-2'
                : 'text-neutral-400 hover:text-red-400'
            }`}
          >
            Sudden Death
          </button>
          <button
            onClick={() => onSelectMode('duel')}
            className={`whitespace-nowrap transition-colors ${
              currentMode === 'duel'
                ? 'text-cyan-400 font-semibold underline underline-offset-8 decoration-cyan-400 decoration-2'
                : 'text-neutral-400 hover:text-cyan-400'
            }`}
          >
            2-Player Duel
          </button>
          <button
            onClick={() => onSelectMode('custom')}
            className={`flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              currentMode === 'custom'
                ? 'text-purple-400 font-semibold underline underline-offset-8 decoration-purple-400 decoration-2'
                : 'text-neutral-400 hover:text-purple-400'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            AI Generator
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Lifeline Shield Toggle */}
          <button
            onClick={onToggleShield}
            title={hasShield ? 'Shield Active (1 error cushion)' : 'Hardcore Sudden Death (Zero errors)'}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              hasShield
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
            }`}
          >
            {hasShield ? <Shield className="w-3.5 h-3.5 text-amber-400" /> : <ShieldAlert className="w-3.5 h-3.5 text-neutral-500" />}
            <span className="hidden sm:inline">{hasShield ? '1 Shield' : 'Hardcore'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            aria-label={soundEnabled ? 'Mute sound' : 'Unmute sound'}
            className="p-2 text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800 rounded-lg hover:border-neutral-700 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-neutral-500" />}
          </button>

          {/* New Run Button */}
          <button
            onClick={onResetGame}
            className="flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-lg shadow-sm transition-all whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">New Ladder</span>
            <span className="sm:hidden">Reset</span>
          </button>
        </div>
      </div>

      {/* Mobile nav row */}
      <div className="flex md:hidden overflow-x-auto px-4 py-2 gap-4 border-t border-neutral-800/60 bg-neutral-950 text-xs font-medium">
        <button
          onClick={() => onSelectMode('trivia')}
          className={`whitespace-nowrap py-1 ${currentMode === 'trivia' ? 'text-amber-400 font-bold border-b border-amber-400' : 'text-neutral-400'}`}
        >
          Solo Ladders
        </button>
        <button
          onClick={() => onSelectMode('word')}
          className={`whitespace-nowrap py-1 ${currentMode === 'word' ? 'text-amber-400 font-bold border-b border-amber-400' : 'text-neutral-400'}`}
        >
          Word Forge
        </button>
        <button
          onClick={() => onSelectMode('sudden_death')}
          className={`whitespace-nowrap py-1 ${currentMode === 'sudden_death' ? 'text-red-400 font-bold border-b border-red-400' : 'text-neutral-400'}`}
        >
          Sudden Death
        </button>
        <button
          onClick={() => onSelectMode('duel')}
          className={`whitespace-nowrap py-1 ${currentMode === 'duel' ? 'text-cyan-400 font-bold border-b border-cyan-400' : 'text-neutral-400'}`}
        >
          2P Duel
        </button>
        <button
          onClick={() => onSelectMode('custom')}
          className={`whitespace-nowrap py-1 ${currentMode === 'custom' ? 'text-purple-400 font-bold border-b border-purple-400' : 'text-neutral-400'}`}
        >
          AI Generator
        </button>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { Users, Swords, Trophy, RefreshCw, ArrowRight, Skull } from 'lucide-react';
import { CURATED_CHAINS } from '../data/chains';
import { ChainDeck } from '../types/game';
import { sound } from '../utils/audio';

interface DuelModeProps {
  onBackToMenu: () => void;
}

export const DuelMode: React.FC<DuelModeProps> = ({ onBackToMenu }) => {
  const [deckIndex, setDeckIndex] = useState<number>(0);
  const currentDeck: ChainDeck = CURATED_CHAINS[deckIndex % CURATED_CHAINS.length];

  const [activePlayer, setActivePlayer] = useState<1 | 2>(1);
  const [currentLinkIndex, setCurrentLinkIndex] = useState<number>(0);
  const [p1Score, setP1Score] = useState<number>(0);
  const [p2Score, setP2Score] = useState<number>(0);
  const [winner, setWinner] = useState<1 | 2 | 'tie' | null>(null);
  const [eliminatedPlayer, setEliminatedPlayer] = useState<1 | 2 | null>(null);
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);

  const activeLink = currentDeck.links[currentLinkIndex];
  const previousAnswer =
    currentLinkIndex === 0
      ? currentDeck.starterLink
      : currentDeck.links[currentLinkIndex - 1].correctAnswer;

  const choices = activeLink
    ? [activeLink.correctAnswer, ...activeLink.distractors].sort(
        (a, b) => a.localeCompare(b)
      )
    : [];

  const handleChoice = (choice: string) => {
    if (selectedChoice || winner || !activeLink) return;
    setSelectedChoice(choice);

    if (choice === activeLink.correctAnswer) {
      sound.playLinkForge();
      if (activePlayer === 1) {
        setP1Score((s) => s + 100);
      } else {
        setP2Score((s) => s + 100);
      }

      // Check if chain is complete
      if (currentLinkIndex + 1 >= currentDeck.links.length) {
        setTimeout(() => {
          sound.playVictoryFanfare();
          if (p1Score > p2Score) setWinner(1);
          else if (p2Score > p1Score) setWinner(2);
          else setWinner('tie');
        }, 500);
      } else {
        // Pass the chain turn to the other player!
        setTimeout(() => {
          setSelectedChoice(null);
          setCurrentLinkIndex((i) => i + 1);
          setActivePlayer((p) => (p === 1 ? 2 : 1));
        }, 500);
      }
    } else {
      // Wrong choice: INSTANT ELIMINATION!
      sound.playChainSnap();
      setEliminatedPlayer(activePlayer);
      setWinner(activePlayer === 1 ? 2 : 1);
    }
  };

  const handleRestart = () => {
    setActivePlayer(1);
    setCurrentLinkIndex(0);
    setP1Score(0);
    setP2Score(0);
    setWinner(null);
    setEliminatedPlayer(null);
    setSelectedChoice(null);
    setDeckIndex((i) => i + 1);
  };

  return (
    <div className="w-full max-w-3xl mx-auto py-4 px-2 sm:px-4">
      {/* 2-Player Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 p-4 bg-neutral-900 border border-cyan-500/30 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-cyan-500/10 rounded-lg border border-cyan-500/30 text-cyan-400">
            <Swords className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                2-Player Chain Duel
              </span>
              <span className="text-[11px] text-neutral-500">· One breaks, other wins!</span>
            </div>
            <h2 className="font-display text-xl font-bold text-white">
              {currentDeck.title}
            </h2>
          </div>
        </div>

        {/* Players Scoreboard */}
        <div className="flex items-center gap-4">
          <div
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              activePlayer === 1 && !winner
                ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-md ring-2 ring-amber-400/40'
                : 'bg-neutral-950 border-neutral-800 text-neutral-400'
            }`}
          >
            <span className="text-[10px] uppercase font-bold block">Player 1</span>
            <span className="font-mono text-base font-bold tabular-nums text-white">
              {p1Score} pts
            </span>
          </div>

          <span className="text-xs text-neutral-600 font-bold">VS</span>

          <div
            className={`px-3 py-1.5 rounded-lg border transition-all ${
              activePlayer === 2 && !winner
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-md ring-2 ring-cyan-400/40'
                : 'bg-neutral-950 border-neutral-800 text-neutral-400'
            }`}
          >
            <span className="text-[10px] uppercase font-bold block">Player 2</span>
            <span className="font-mono text-base font-bold tabular-nums text-white">
              {p2Score} pts
            </span>
          </div>
        </div>
      </div>

      {!winner && activeLink ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 shadow-2xl relative">
          {/* Active Turn Banner */}
          <div className="mb-5 flex items-center justify-between pb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-400">Turn to Forge:</span>
              <span
                className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                  activePlayer === 1
                    ? 'bg-amber-400 text-neutral-950'
                    : 'bg-cyan-400 text-neutral-950'
                }`}
              >
                PLAYER {activePlayer}'S LINK
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs sm:text-sm">
              <span className="text-neutral-500">Connecting From:</span>
              <span className="font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 flex items-center gap-1">
                {previousAnswer} <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>

          {/* Question */}
          <div className="mb-6">
            <span className="text-xs font-semibold uppercase text-amber-400 block mb-1">
              Link {activeLink.linkIndex} of {currentDeck.links.length}
            </span>
            <h3 className="text-lg sm:text-xl font-semibold text-white leading-relaxed">
              {activeLink.question}
            </h3>
          </div>

          {/* Choices */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {choices.map((choice) => {
              const isSelected = selectedChoice === choice;
              return (
                <button
                  key={choice}
                  disabled={Boolean(selectedChoice)}
                  onClick={() => handleChoice(choice)}
                  className={`p-4 rounded-xl border text-left font-medium text-sm sm:text-base transition-all ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-white'
                      : 'bg-neutral-950/70 border-neutral-800 text-neutral-200 hover:border-amber-500/50 hover:bg-neutral-800'
                  }`}
                >
                  {choice}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        /* Winner Modal */
        <div className="bg-neutral-900 border-2 border-amber-400 rounded-2xl p-6 sm:p-8 shadow-2xl animate-scaleUp text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center">
            <Trophy className="w-8 h-8" />
          </div>

          {eliminatedPlayer ? (
            <div className="mb-4">
              <span className="text-xs font-bold uppercase text-red-400 block mb-1">
                Player {eliminatedPlayer} Made A Fatal Link & Was Eliminated!
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                PLAYER {winner} WINS THE DUEL!
              </h3>
            </div>
          ) : (
            <div className="mb-4">
              <span className="text-xs font-bold uppercase text-emerald-400 block mb-1">
                Full Chain Survived!
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                {winner === 'tie' ? 'IT IS A DEAD HEAT TIE!' : `PLAYER ${winner} TRIUMPHS!`}
              </h3>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto mb-6 text-sm">
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <span className="text-xs text-neutral-500 block">Player 1</span>
              <span className="font-mono text-lg font-bold text-amber-400">{p1Score} pts</span>
            </div>
            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800">
              <span className="text-xs text-neutral-500 block">Player 2</span>
              <span className="font-mono text-lg font-bold text-cyan-400">{p2Score} pts</span>
            </div>
          </div>

          <div className="flex gap-3 justify-center">
            <button
              onClick={handleRestart}
              className="flex items-center gap-2 py-3 px-6 bg-amber-400 hover:bg-amber-300 font-bold text-neutral-950 rounded-xl shadow-lg transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              Next Duel Ladder
            </button>
            <button
              onClick={onBackToMenu}
              className="py-3 px-5 bg-neutral-800 hover:bg-neutral-700 font-semibold text-white rounded-xl border border-neutral-700"
            >
              Back to Solo
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, CheckCircle2, ArrowRight, Share2, Sparkles, RefreshCw } from 'lucide-react';
import { ChainDeck } from '../types/game';

interface VictoryModalProps {
  deck: ChainDeck;
  score: number;
  timeBonus: number;
  streak: number;
  onNextLadder: () => void;
  onReplay: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  deck,
  score,
  timeBonus,
  streak,
  onNextLadder,
  onReplay,
}) => {
  useEffect(() => {
    // Launch celebratory confetti bursts
    const end = Date.now() + 1500;
    const colors = ['#f59e0b', '#10b981', '#3b82f6', '#f43f5e'];

    (function frame() {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors,
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  }, []);

  const totalScore = score + timeBonus;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-neutral-900 border-2 border-amber-400 rounded-2xl p-6 sm:p-8 shadow-[0_0_50px_rgba(245,158,11,0.3)] relative overflow-hidden animate-scaleUp max-h-[90vh] overflow-y-auto">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-emerald-400 to-amber-400" />

        {/* Victory Header */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
            <Trophy className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" /> Zero Links Severed
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              UNBROKEN CHAIN FORGED!
            </h2>
          </div>
        </div>

        {/* Deck Title */}
        <div className="bg-neutral-950/70 border border-neutral-800 rounded-xl p-4 mb-6">
          <span className="text-xs text-amber-400 font-semibold uppercase tracking-wider block mb-1">
            Completed Ladder
          </span>
          <h3 className="text-lg font-bold text-white mb-3">{deck.title}</h3>

          {/* Full Connection Pathway */}
          <div className="space-y-2">
            <div className="text-xs text-neutral-400 font-medium mb-1">
              Full Unbroken Sequence:
            </div>
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="px-2.5 py-1 bg-amber-500/20 text-amber-300 font-bold rounded border border-amber-500/30">
                {deck.starterLink}
              </span>
              {deck.links.map((link) => (
                <React.Fragment key={link.linkIndex}>
                  <ArrowRight className="w-3 h-3 text-neutral-600" />
                  <span className="px-2 py-1 bg-neutral-800 text-neutral-200 font-semibold rounded border border-neutral-700">
                    {link.correctAnswer}
                  </span>
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="grid grid-cols-3 gap-3 mb-6 text-center">
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 uppercase font-medium block">
              Base Score
            </span>
            <span className="font-mono text-base sm:text-lg font-bold text-white tabular-nums">
              {score}
            </span>
          </div>
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 uppercase font-medium block">
              Speed Bonus
            </span>
            <span className="font-mono text-base sm:text-lg font-bold text-emerald-400 tabular-nums">
              +{timeBonus}
            </span>
          </div>
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-amber-500/30 bg-amber-500/5">
            <span className="text-[11px] text-amber-400 uppercase font-bold block">
              Final Total
            </span>
            <span className="font-mono text-lg sm:text-xl font-extrabold text-amber-300 tabular-nums">
              {totalScore}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={onNextLadder}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3 text-sm font-bold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl shadow-lg transition-all"
          >
            <Sparkles className="w-4 h-4" />
            Next Chain Ladder
          </button>

          <button
            onClick={onReplay}
            className="flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl border border-neutral-700 transition-all"
          >
            <RefreshCw className="w-4 h-4 text-neutral-400" />
            Replay Ladder
          </button>
        </div>
      </div>
    </div>
  );
};

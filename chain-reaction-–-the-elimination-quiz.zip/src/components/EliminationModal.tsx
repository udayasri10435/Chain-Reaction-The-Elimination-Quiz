import React from 'react';
import { Skull, AlertTriangle, RefreshCw, Compass, ArrowRight, ZapOff } from 'lucide-react';
import { ChainLink } from '../types/game';

interface EliminationModalProps {
  failedLink: ChainLink;
  previousAnswer: string;
  selectedWrongAnswer: string;
  linksForged: number;
  totalLinks: number;
  score: number;
  streak: number;
  onRetry: () => void;
  onBrowseLadders: () => void;
  onSuddenDeath: () => void;
}

export const EliminationModal: React.FC<EliminationModalProps> = ({
  failedLink,
  previousAnswer,
  selectedWrongAnswer,
  linksForged,
  totalLinks,
  score,
  streak,
  onRetry,
  onBrowseLadders,
  onSuddenDeath,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-neutral-900 border-2 border-red-500/80 rounded-2xl p-6 sm:p-8 shadow-[0_0_50px_rgba(239,68,68,0.3)] relative overflow-hidden animate-scaleUp">
        {/* Ambient alert glow */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-red-600 via-amber-500 to-red-600" />
        <div className="absolute -right-16 -top-16 w-36 h-36 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header: Elimination Banner */}
        <div className="flex items-center gap-3 mb-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-red-500/20 border border-red-500/40 text-red-500">
            <ZapOff className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-400">
              <AlertTriangle className="w-3.5 h-3.5" /> Fatal Error
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              CHAIN SEVERED · ELIMINATED
            </h2>
          </div>
        </div>

        {/* Failure Breakdown Card */}
        <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-4 sm:p-5 mb-6 space-y-3.5">
          <div className="text-xs text-neutral-400">
            <span className="font-semibold text-neutral-300">Failure Point:</span> Link {failedLink.linkIndex} of {totalLinks}
          </div>

          <div className="text-sm text-neutral-300 leading-snug">
            "{failedLink.question}"
          </div>

          {/* Connection Comparison */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-red-950/40 border border-red-900/50 rounded-lg">
              <span className="text-[11px] uppercase tracking-wider font-bold text-red-400 block mb-1">
                Your Answer (Severed)
              </span>
              <span className="font-semibold text-red-200 text-sm line-through decoration-red-500 decoration-2">
                {selectedWrongAnswer || 'Time Expired'}
              </span>
            </div>

            <div className="p-3 bg-emerald-950/40 border border-emerald-900/50 rounded-lg">
              <span className="text-[11px] uppercase tracking-wider font-bold text-emerald-400 block mb-1">
                Correct Connecting Link
              </span>
              <span className="font-semibold text-emerald-200 text-sm">
                {failedLink.correctAnswer}
              </span>
            </div>
          </div>

          {/* Logical connection explanation */}
          <div className="text-xs text-neutral-400 pt-2 border-t border-neutral-800/80 flex items-start gap-2">
            <span className="text-amber-400 font-semibold shrink-0">The Connection:</span>
            <span>
              {failedLink.connectionExplanation} (Connected from: <strong>{previousAnswer}</strong>)
            </span>
          </div>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-3 gap-3 mb-6 text-center">
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 uppercase font-medium block">
              Links Forged
            </span>
            <span className="font-mono text-lg font-bold text-white tabular-nums">
              {linksForged} / {totalLinks}
            </span>
          </div>
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 uppercase font-medium block">
              Chain Score
            </span>
            <span className="font-mono text-lg font-bold text-amber-400 tabular-nums">
              {score}
            </span>
          </div>
          <div className="p-3 bg-neutral-950/60 rounded-xl border border-neutral-800">
            <span className="text-[11px] text-neutral-500 uppercase font-medium block">
              Best Streak
            </span>
            <span className="font-mono text-lg font-bold text-neutral-200 tabular-nums">
              {streak}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={onRetry}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-bold text-neutral-950 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 rounded-xl shadow-lg transition-all"
          >
            <RefreshCw className="w-4 h-4" />
            Retry This Ladder
          </button>

          <button
            onClick={onBrowseLadders}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-neutral-800 hover:bg-neutral-700 rounded-xl border border-neutral-700 transition-all"
          >
            <Compass className="w-4 h-4 text-neutral-400" />
            Switch Ladder
          </button>

          <button
            onClick={onSuddenDeath}
            className="flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-red-300 hover:text-white bg-red-950/50 hover:bg-red-900/60 border border-red-800/60 rounded-xl transition-all"
          >
            <Skull className="w-4 h-4 text-red-400" />
            <span className="hidden sm:inline">Gauntlet</span>
          </button>
        </div>
      </div>
    </div>
  );
};

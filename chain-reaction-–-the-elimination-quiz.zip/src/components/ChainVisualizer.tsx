import React from 'react';
import { Check, Flame, Lock, Zap, XOctagon } from 'lucide-react';
import { ChainLink } from '../types/game';

interface ChainVisualizerProps {
  starterLink: string;
  links: ChainLink[];
  currentLinkIndex: number; // 0 means starter is visible, answering link 0 in array (linkIndex 1)
  isEliminated: boolean;
  eliminatedIndex?: number;
  unbrokenStreak: number;
}

export const ChainVisualizer: React.FC<ChainVisualizerProps> = ({
  starterLink,
  links,
  currentLinkIndex,
  isEliminated,
  eliminatedIndex,
  unbrokenStreak,
}) => {
  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800 rounded-xl p-4 sm:p-6 shadow-xl relative overflow-hidden backdrop-blur-sm">
      {/* Background ambient gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 via-transparent to-transparent pointer-events-none" />

      {/* Top Chain Status line */}
      <div className="flex items-center justify-between mb-4 border-b border-neutral-800/80 pb-3 text-xs sm:text-sm">
        <div className="flex items-center gap-2">
          <span className="text-neutral-400">Chain Tension:</span>
          <span className={`font-semibold ${isEliminated ? 'text-red-500' : 'text-amber-400'}`}>
            {isEliminated ? 'SEVERED' : `${currentLinkIndex} of ${links.length} Connected`}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-neutral-400">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span>Streak:</span>
            <span className="font-semibold text-white tabular-nums">{unbrokenStreak}</span>
          </div>
        </div>
      </div>

      {/* Vertical/Stacked Chain Ladder Display */}
      <div className="relative flex flex-col items-center">
        {/* Anchor: Starter Link */}
        <div className="w-full max-w-md flex flex-col items-center">
          <div className="w-full flex items-center justify-between px-4 py-2.5 bg-neutral-800/90 border border-amber-500/40 rounded-lg shadow-sm">
            <div className="flex items-center gap-2.5">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs">
                0
              </span>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-amber-400/80 font-bold block">
                  Anchor Link
                </span>
                <span className="font-display font-bold text-white text-sm sm:text-base tracking-wide">
                  {starterLink}
                </span>
              </div>
            </div>
            <span className="text-xs text-amber-400 font-medium flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> Locked
            </span>
          </div>

          {/* First interlock connector */}
          <div className="h-5 w-1 bg-gradient-to-b from-amber-500/60 to-neutral-700 relative flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full border border-amber-500/50 bg-neutral-900" />
          </div>
        </div>

        {/* Following Chain Links */}
        {links.map((link, idx) => {
          const isCompleted = idx < currentLinkIndex;
          const isCurrent = idx === currentLinkIndex && !isEliminated;
          const isBroken = isEliminated && idx === (eliminatedIndex ?? currentLinkIndex);
          const isFuture = idx > currentLinkIndex && !isBroken;

          return (
            <div key={link.linkIndex} className="w-full max-w-md flex flex-col items-center">
              <div
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-300 relative ${
                  isBroken
                    ? 'bg-red-950/70 border-2 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-chain-break'
                    : isCompleted
                    ? 'bg-neutral-800/90 border border-amber-500/30 shadow-sm'
                    : isCurrent
                    ? 'bg-neutral-900 border-2 border-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.3)] animate-pulse-glow'
                    : 'bg-neutral-950/70 border border-neutral-800 opacity-60'
                }`}
              >
                {/* Left: Number + Answer or Mystery */}
                <div className="flex items-center gap-3">
                  <span
                    className={`flex items-center justify-center w-6 h-6 rounded-full font-bold text-xs ${
                      isBroken
                        ? 'bg-red-600 text-white'
                        : isCompleted
                        ? 'bg-amber-500 text-neutral-950'
                        : isCurrent
                        ? 'bg-amber-400 text-neutral-950 animate-bounce'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    {link.linkIndex}
                  </span>

                  <div>
                    {isCompleted ? (
                      <div>
                        <span className="font-display font-bold text-white text-sm sm:text-base tracking-wide">
                          {link.correctAnswer}
                        </span>
                        <p className="text-[11px] text-neutral-400 line-clamp-1">
                          {link.connectionExplanation}
                        </p>
                      </div>
                    ) : isBroken ? (
                      <div>
                        <span className="font-display font-bold text-red-400 text-sm sm:text-base tracking-wide flex items-center gap-1.5">
                          <XOctagon className="w-4 h-4 text-red-500" />
                          CHAIN SEVERED HERE
                        </span>
                        <p className="text-[11px] text-red-300/80">
                          Expected Link: {link.correctAnswer}
                        </p>
                      </div>
                    ) : isCurrent ? (
                      <div className="flex items-center gap-2">
                        <span className="font-display font-semibold text-amber-300 text-sm tracking-wide flex items-center gap-1.5">
                          <Zap className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                          Under High Tension...
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-neutral-500 text-sm">
                        <Lock className="w-3.5 h-3.5" />
                        <span className="tracking-widest">········</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right: Status Icon */}
                <div className="text-right">
                  {isCompleted && (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                      <Check className="w-3 h-3" /> Intact
                    </span>
                  )}
                  {isCurrent && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">
                      FORGING
                    </span>
                  )}
                  {isBroken && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-red-400 bg-red-500/20 px-2 py-0.5 rounded animate-pulse">
                      SNAPPED
                    </span>
                  )}
                  {isFuture && (
                    <span className="text-xs text-neutral-600 font-mono">
                      LINK {link.linkIndex}
                    </span>
                  )}
                </div>
              </div>

              {/* Interlocking ring connector if not the last link */}
              {idx < links.length - 1 && (
                <div className="h-5 w-1 bg-gradient-to-b from-neutral-700 to-neutral-800 relative flex items-center justify-center">
                  <div
                    className={`w-2.5 h-2.5 rounded-full border transition-colors ${
                      isCompleted
                        ? 'border-amber-500 bg-amber-500/30'
                        : isBroken
                        ? 'border-red-500 bg-red-500/30'
                        : 'border-neutral-700 bg-neutral-900'
                    }`}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

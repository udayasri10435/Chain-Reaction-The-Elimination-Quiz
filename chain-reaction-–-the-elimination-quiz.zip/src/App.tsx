import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { CURATED_CHAINS } from './data/chains';
import { ChainDeck, ChainLink, GameMode, GameStatus, PlayerStats } from './types/game';
import { Header } from './components/Header';
import { ChainVisualizer } from './components/ChainVisualizer';
import { QuestionCard } from './components/QuestionCard';
import { EliminationModal } from './components/EliminationModal';
import { VictoryModal } from './components/VictoryModal';
import { DeckSelector } from './components/DeckSelector';
import { SuddenDeathMode } from './components/SuddenDeathMode';
import { DuelMode } from './components/DuelMode';
import { AIGeneratorModal } from './components/AIGeneratorModal';
import { LeaderboardView } from './components/LeaderboardView';
import { sound } from './utils/audio';

export default function App() {
  // Navigation & Game State
  const [currentMode, setCurrentMode] = useState<GameMode>('trivia');
  const [gameStatus, setGameStatus] = useState<GameStatus>('TITLE_MENU');

  // Decks
  const [availableDecks, setAvailableDecks] = useState<ChainDeck[]>(CURATED_CHAINS);
  const [currentDeckId, setCurrentDeckId] = useState<string>(CURATED_CHAINS[0].id);

  // Active Game State
  const [currentLinkIdx, setCurrentLinkIdx] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [timeRemaining, setTimeRemaining] = useState<number>(18);
  const totalTimePerLink = 18;

  // Settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('chain_reaction_sound') !== 'false';
  });
  const [hasShield, setHasShield] = useState<boolean>(false);
  const [shieldActiveInRound, setShieldActiveInRound] = useState<boolean>(false);

  // Elimination context
  const [failedLink, setFailedLink] = useState<ChainLink | null>(null);
  const [wrongAnswerGiven, setWrongAnswerGiven] = useState<string>('');
  const [eliminatedLinkIndex, setEliminatedLinkIndex] = useState<number>(0);

  // Modals
  const [showAIGenerator, setShowAIGenerator] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);

  // Career Statistics
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const stored = localStorage.getItem('chain_reaction_stats');
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return {
      gamesPlayed: 0,
      unbrokenChainsCompleted: 0,
      eliminations: 0,
      longestSurvivalStreak: 0,
      totalLinksForged: 0,
      highScore: 0,
    };
  });

  const saveStats = useCallback((updater: (prev: PlayerStats) => PlayerStats) => {
    setStats((prev) => {
      const updated = updater(prev);
      try {
        localStorage.setItem('chain_reaction_stats', JSON.stringify(updated));
      } catch {
        // storage error
      }
      return updated;
    });
  }, []);

  // Update sound engine
  useEffect(() => {
    sound.enabled = soundEnabled;
    localStorage.setItem('chain_reaction_sound', String(soundEnabled));
  }, [soundEnabled]);

  const activeDeck = useMemo(() => {
    return availableDecks.find((d) => d.id === currentDeckId) || availableDecks[0];
  }, [availableDecks, currentDeckId]);

  const activeLink = activeDeck.links[currentLinkIdx];
  const previousAnswer =
    currentLinkIdx === 0
      ? activeDeck.starterLink
      : activeDeck.links[currentLinkIdx - 1]?.correctAnswer || activeDeck.starterLink;

  // Start a chosen deck
  const handleStartDeck = useCallback((deck: ChainDeck) => {
    setCurrentDeckId(deck.id);
    setCurrentLinkIdx(0);
    setScore(0);
    setStreak(0);
    setTimeRemaining(18);
    setShieldActiveInRound(hasShield);
    setFailedLink(null);
    setWrongAnswerGiven('');
    setGameStatus('PLAYING');
  }, [hasShield]);

  // Handle wrong answer elimination
  const triggerElimination = useCallback(
    (chosenAnswer: string, link: ChainLink) => {
      // Check if shield can absorb
      if (shieldActiveInRound) {
        sound.playShieldDeflect();
        setShieldActiveInRound(false);
        setTimeRemaining(12);
        return;
      }

      sound.playChainSnap();
      setFailedLink(link);
      setWrongAnswerGiven(chosenAnswer);
      setEliminatedLinkIndex(currentLinkIdx);
      setGameStatus('ELIMINATED');

      saveStats((prev) => ({
        ...prev,
        gamesPlayed: prev.gamesPlayed + 1,
        eliminations: prev.eliminations + 1,
      }));
    },
    [shieldActiveInRound, currentLinkIdx, saveStats]
  );

  // Timer countdown during active play
  useEffect(() => {
    if (gameStatus !== 'PLAYING') return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          if (activeLink) {
            triggerElimination('TIME EXPIRED', activeLink);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameStatus, activeLink, triggerElimination]);

  // Answer selection handler
  const handleSelectAnswer = (chosen: string) => {
    if (gameStatus !== 'PLAYING' || !activeLink) return;

    if (chosen === activeLink.correctAnswer) {
      // Successful connection!
      sound.playLinkForge();
      const points = 100 + timeRemaining * 10;
      setScore((s) => s + points);
      setStreak((st) => st + 1);

      saveStats((prev) => ({
        ...prev,
        totalLinksForged: prev.totalLinksForged + 1,
        longestSurvivalStreak: Math.max(prev.longestSurvivalStreak, streak + 1),
      }));

      // Check if this was the last link in the chain
      if (currentLinkIdx + 1 >= activeDeck.links.length) {
        sound.playVictoryFanfare();
        setGameStatus('VICTORY');
        saveStats((prev) => ({
          ...prev,
          gamesPlayed: prev.gamesPlayed + 1,
          unbrokenChainsCompleted: prev.unbrokenChainsCompleted + 1,
          highScore: Math.max(prev.highScore, score + points),
        }));
      } else {
        // Advance to next link
        setGameStatus('LINK_SUCCESS');
        setTimeout(() => {
          setCurrentLinkIdx((idx) => idx + 1);
          setTimeRemaining(18);
          setGameStatus('PLAYING');
        }, 400);
      }
    } else {
      triggerElimination(chosen, activeLink);
    }
  };

  // Keyboard shortcut listener for options (1-4)
  useEffect(() => {
    if (gameStatus !== 'PLAYING' || !activeLink) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      const choices = [activeLink.correctAnswer, ...activeLink.distractors];
      // Note: we can map 1-4 or a-d
      if (['1', '2', '3', '4'].includes(key)) {
        const index = parseInt(key, 10) - 1;
        // In QuestionCard choices are shuffled deterministically, but we let click handle directly
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStatus, activeLink]);

  // Mode changes
  const handleSelectMode = (mode: GameMode) => {
    setCurrentMode(mode);
    if (mode === 'custom') {
      setShowAIGenerator(true);
    } else if (mode === 'trivia') {
      const firstTrivia = availableDecks.find((d) => d.mode === 'trivia');
      if (firstTrivia) setCurrentDeckId(firstTrivia.id);
      setGameStatus('TITLE_MENU');
    } else if (mode === 'word') {
      const firstWord = availableDecks.find((d) => d.mode === 'word');
      if (firstWord) setCurrentDeckId(firstWord.id);
      setGameStatus('TITLE_MENU');
    } else if (mode === 'sudden_death' || mode === 'duel') {
      // handed off to their dedicated views
    }
  };

  const handleNextLadder = () => {
    const currentIndex = availableDecks.findIndex((d) => d.id === currentDeckId);
    const nextDeck = availableDecks[(currentIndex + 1) % availableDecks.length];
    handleStartDeck(nextDeck);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-400 selection:text-neutral-950">
      {/* Top Navigation Bar adhering to Top Bar Contract */}
      <Header
        currentMode={currentMode}
        onSelectMode={handleSelectMode}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled((s) => !s)}
        hasShield={hasShield}
        onToggleShield={() => setHasShield((s) => !s)}
        onResetGame={() => {
          setGameStatus('TITLE_MENU');
          setCurrentLinkIdx(0);
        }}
      />

      {/* Main Game Stage */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 flex flex-col justify-start">
        {currentMode === 'sudden_death' ? (
          <SuddenDeathMode
            onBackToMenu={() => setCurrentMode('trivia')}
            soundEnabled={soundEnabled}
            hasShield={hasShield}
          />
        ) : currentMode === 'duel' ? (
          <DuelMode onBackToMenu={() => setCurrentMode('trivia')} />
        ) : gameStatus === 'TITLE_MENU' ? (
          <div className="space-y-8 animate-fadeIn">
            {/* Hero Kicker Banner */}
            <div className="relative rounded-3xl p-6 sm:p-10 border border-neutral-800 bg-neutral-900/60 overflow-hidden shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 via-transparent to-red-500/5 pointer-events-none" />
              <div className="max-w-2xl relative z-10">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
                  <span>Elimination Rules</span>
                  <span>·</span>
                  <span>Zero Broken Links Tolerated</span>
                </div>
                <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight text-balance mb-4">
                  Every Answer Bridges To The Next.
                </h1>
                <p className="text-sm sm:text-base text-neutral-300 leading-relaxed mb-6">
                  In Chain Reaction, every answer is the foundation of the following question. 
                  One misplaced link breaks the circuit and triggers instant elimination.
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => handleStartDeck(activeDeck)}
                    className="px-6 py-3 bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-neutral-950 font-bold text-sm rounded-xl shadow-lg transition-all"
                  >
                    Start Active Ladder ({activeDeck.title})
                  </button>
                  <button
                    onClick={() => setShowLeaderboard(true)}
                    className="px-5 py-3 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-sm rounded-xl border border-neutral-700 transition-all"
                  >
                    Career Track Record
                  </button>
                </div>
              </div>
            </div>

            {/* Deck Selector Grid */}
            <DeckSelector
              decks={availableDecks.filter((d) => (currentMode === 'word' ? d.mode === 'word' : d.mode === 'trivia'))}
              selectedDeckId={currentDeckId}
              onSelectDeck={handleStartDeck}
              onOpenAIGenerator={() => setShowAIGenerator(true)}
              onStartSuddenDeath={() => setCurrentMode('sudden_death')}
            />
          </div>
        ) : (
          /* Live Game Arena View */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start animate-fadeIn">
            {/* Left 4 Cols: The Vertical Chain Visualizer */}
            <div className="lg:col-span-5 w-full">
              <ChainVisualizer
                starterLink={activeDeck.starterLink}
                links={activeDeck.links}
                currentLinkIndex={currentLinkIdx}
                isEliminated={gameStatus === 'ELIMINATED'}
                eliminatedIndex={eliminatedLinkIndex}
                unbrokenStreak={streak}
              />
            </div>

            {/* Right 7-8 Cols: Active Question Card & Controls */}
            <div className="lg:col-span-7 w-full flex flex-col gap-6">
              {activeLink && (
                <QuestionCard
                  link={activeLink}
                  previousAnswer={previousAnswer}
                  totalLinks={activeDeck.links.length}
                  timeRemaining={timeRemaining}
                  totalTime={totalTimePerLink}
                  hasShield={shieldActiveInRound}
                  onSelectAnswer={handleSelectAnswer}
                  disabled={gameStatus !== 'PLAYING'}
                />
              )}

              {/* Ladder Details Bar */}
              <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xl flex items-center justify-between text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-neutral-300">Ladder:</span>
                  <span className="text-white">{activeDeck.title}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span>Score: <strong className="text-amber-400 tabular-nums">{score}</strong></span>
                  <button
                    onClick={() => setGameStatus('TITLE_MENU')}
                    className="text-neutral-400 hover:text-white underline underline-offset-4"
                  >
                    Change Ladder
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Elimination Modal */}
      {gameStatus === 'ELIMINATED' && failedLink && (
        <EliminationModal
          failedLink={failedLink}
          previousAnswer={previousAnswer}
          selectedWrongAnswer={wrongAnswerGiven}
          linksForged={currentLinkIdx}
          totalLinks={activeDeck.links.length}
          score={score}
          streak={streak}
          onRetry={() => handleStartDeck(activeDeck)}
          onBrowseLadders={() => setGameStatus('TITLE_MENU')}
          onSuddenDeath={() => {
            setCurrentMode('sudden_death');
            setGameStatus('PLAYING');
          }}
        />
      )}

      {/* Victory Modal */}
      {gameStatus === 'VICTORY' && (
        <VictoryModal
          deck={activeDeck}
          score={score}
          timeBonus={timeRemaining * 15}
          streak={streak}
          onNextLadder={handleNextLadder}
          onReplay={() => handleStartDeck(activeDeck)}
        />
      )}

      {/* Custom AI Chain Generator Modal */}
      {showAIGenerator && (
        <AIGeneratorModal
          onStartCustomDeck={(newDeck) => {
            setAvailableDecks((prev) => [newDeck, ...prev]);
            setShowAIGenerator(false);
            handleStartDeck(newDeck);
          }}
          onClose={() => setShowAIGenerator(false)}
        />
      )}

      {/* Leaderboard View Modal */}
      {showLeaderboard && (
        <LeaderboardView
          stats={stats}
          onClearStats={() => {
            const fresh: PlayerStats = {
              gamesPlayed: 0,
              unbrokenChainsCompleted: 0,
              eliminations: 0,
              longestSurvivalStreak: 0,
              totalLinksForged: 0,
              highScore: 0,
            };
            setStats(fresh);
            localStorage.removeItem('chain_reaction_stats');
          }}
          onClose={() => setShowLeaderboard(false)}
        />
      )}

      {/* Clean Footer adhering to Section 1.B */}
      <footer className="w-full border-t border-neutral-900 bg-neutral-950 py-4 text-center text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Chain Reaction Quiz · High-Stakes Linked Trivia</span>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowLeaderboard(true)}
              className="hover:text-neutral-300 transition-colors"
            >
              Career Records
            </button>
            <span>·</span>
            <button
              onClick={() => setShowAIGenerator(true)}
              className="hover:text-neutral-300 transition-colors"
            >
              AI Chain Studio
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

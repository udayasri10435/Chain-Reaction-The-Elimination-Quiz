export type GameMode = 'trivia' | 'word' | 'sudden_death' | 'duel' | 'custom';

export type GameStatus =
  | 'TITLE_MENU'
  | 'PLAYING'
  | 'LINK_SUCCESS'
  | 'ELIMINATED'
  | 'VICTORY'
  | 'SUMMARY';

export interface ChainLink {
  linkIndex: number;
  question: string;
  correctAnswer: string;
  distractors: string[]; // 3 tricky distractors
  connectionExplanation: string; // Explains how it ties to previous answer
  hint?: string;
}

export interface ChainDeck {
  id: string;
  title: string;
  topic: string;
  mode: 'trivia' | 'word';
  difficulty: 'Standard' | 'Hard' | 'Extreme';
  starterLink: string;
  starterDescription: string;
  links: ChainLink[];
}

export interface PlayerStats {
  gamesPlayed: number;
  unbrokenChainsCompleted: number;
  eliminations: number;
  longestSurvivalStreak: number;
  totalLinksForged: number;
  highScore: number;
  lastPlayed?: string;
}

export interface DuelPlayer {
  id: 1 | 2;
  name: string;
  linksForged: number;
  score: number;
  status: 'alive' | 'eliminated' | 'winner';
}

export interface GameSettings {
  soundEnabled: boolean;
  soundVolume: number;
  timerDuration: number; // e.g. 15s or 20s
  hasShield: boolean; // 1 shield allowed vs instant 1-strike elimination
}
